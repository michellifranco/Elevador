package com.example.elevador

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
    fun Entrar(elevador:View) {
        var valido = true
        if (totalSuportado.text.toString().toDouble() < 1 || totalSuportado.text.toString().toDouble() > 600) {
            valido = false
        }

        if (!nome.text.contains(" ")) {
            valido = false
        }

        if (peso.text.toString().toDouble() < 1 || peso.text.toString().toDouble() > 500) {
            valido = false
        }

        if (!valido) {
            Toast.makeText(this, "Por favor, insira um valor válido.", Toast.LENGTH_SHORT).show()
        } else {
            if (peso.text.toString().toDouble() + valor.text.toString().toDouble() > totalSuportado.text.toString().toDouble()) {
                mensagem.text = "Você não pode entrar, ${nome.text}"
                mensagem.setTextColor(Color.RED)
            } else {
                valor.text = "${valor.text.toString().toDouble() + peso.text.toString().toDouble()}"
                mensagem.text = "Você entrou, ${nome.text}!"
                mensagem.setTextColor(Color.GREEN)
                nome.setText("")
                peso.setText("")
            }

        }



    }
}